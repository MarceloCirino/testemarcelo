﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.Domain.Enums
{
    public enum TipoConta
    {
        Corrente = 1,
        Poupanca = 2
    }
}
