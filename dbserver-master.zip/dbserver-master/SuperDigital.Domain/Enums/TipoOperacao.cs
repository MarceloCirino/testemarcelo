﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SuperDigital.Domain.Enums
{
    public enum TipoOperacao
    {
        Credito = 1,
        Debito = 2
    }
}
